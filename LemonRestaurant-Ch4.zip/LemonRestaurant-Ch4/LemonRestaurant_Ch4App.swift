//
//  LemonRestaurant_Ch4App.swift
//  LemonRestaurant-Ch4
//
//  Created by Marlo baguyos on 10/14/25.
//

import SwiftUI

@main
struct LemonRestaurant_Ch4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
